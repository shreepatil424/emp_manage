| Task Has Been Made In CODEIGNITER MVC Based |
|---------------------------------------------|

All this things has been done.
----------------------------------------------------------------------------------- 
1.Employee signup and login. 

2.Implement the Employee Registration system (with jquery validation).

3.Based on Date of Birth need to calculate the age.

4.Email should be unique. if same email trying to register again it will show error.

5.Login system based on the email id and password. (session based URL validation)

6.Edit employee profile (with jquery validation).

------------------------------------------------------------------------------------
Rest of part Leave Calculation Not done
------------------------------------------------------------------------------------
1) Leave Calculation 
	- Not able to understand what exacly i want to do with this task. 
	- so i have not done this task.

------------------------------------------------------------------------------------
Database : employee.sql
------------------------------------------------------------------------------------
Some credential to login system
-------------------------------
username -Viraj@mailinator.com
password -9595953355

username -Rudhra@mailinator.com
password -9595953366	
------------------------------------------------------------------------------------

Note -- I'm integrated Ui interface to this task so, 
	  - thats why im getting more time to compleet this task,
	  - im not abale to understand Leave Calculation task so have not done this task.   
------------------------------------------------------------------------------------



